package com.student.auth.entity;

import lombok.Data;

/**
* @description: QuestionXztOptions 选择题的选项数据 实体
*/
@Data
public class QuestionXztOptions {
//主键 id
private Long id;
//选择题 A 选项
private String optionA;
//选择题 B 选项
private String optionB;
//选择题 c 选项
private String optionC;
//选择题 d 选项
private String optionD;
/**
* 问题编号 id
*/
private Long questionId;
}