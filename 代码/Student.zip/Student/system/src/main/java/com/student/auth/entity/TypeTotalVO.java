package com.student.auth.entity;

import lombok.Data;

/**
 * @description: TypeTotalVO  问题的题型 实体类
 */
@Data
//先创建一个响应类，里面封装了每道题目的题型和对应题型的数量。
public class TypeTotalVO {
   //题型
    private Long q_typeid;
   //总数
    private Long totalNum;
}
