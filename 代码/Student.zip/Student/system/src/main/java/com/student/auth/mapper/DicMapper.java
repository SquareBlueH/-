package com.student.auth.mapper;

import com.student.auth.entity.DicTypeData;
import org.apache.ibatis.annotations.Select;

import java.util.List;

//@Mapper
public interface DicMapper {
/**
* 查询试卷等级
* @return
*/
@Select("select * from t_dictype_data where typeid=1")
List<DicTypeData> findLevels();
}