package com.student.auth.mapper;

import com.student.auth.entity.ScoreDetail;
import com.student.auth.entity.StuPaperQuestion;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface StuQuestionRecordsMapper {
    /**
     * 查询学生的考卷的每题记录
     *
     * @param scoreDetail areturn
     */
    StuPaperQuestion queryPaperDetail(ScoreDetail scoreDetail);
}

