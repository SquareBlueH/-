package com.student.auth.query;

import lombok.Data;

/**
 * 七、老师功能完善
 * 1.1、老师阅卷功能列表
 * @description: ScoreDetailQuery 接收前台的查询参数  问题编号name="questionId"  试卷编号name="paperId" 
 */
@Data
public class ScoreDetailQuery  extends BaseQuery{
    /**
     * 试题的编号
     */
    private Long questionId;
    /**
     * 问题编号
     */
    private Long paperId;
}
