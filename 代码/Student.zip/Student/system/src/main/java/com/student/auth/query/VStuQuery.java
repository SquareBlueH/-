package com.student.auth.query;

import lombok.Data;

/**1.3、成绩管理
 * @description:
 */
@Data
public class VStuQuery extends BaseQuery {
    //学生昵称
    private String nickName;
    //试卷名称
    private String name;
}
