package com.student.auth.service;

import com.student.auth.entity.DicTypeData;

import java.util.List;

public interface DicService {
        /**
        * 查询试卷等级
        * @return
        */
        List<DicTypeData> findLevels();
}