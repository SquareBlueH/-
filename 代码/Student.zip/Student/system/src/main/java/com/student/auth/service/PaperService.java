package com.student.auth.service;


import com.student.auth.entity.Paper;
import com.student.auth.entity.PaperGengerateVO;
import com.student.auth.entity.PaperQuestion;
import com.student.auth.entity.TypeTotalVO;
import com.student.auth.query.PaperQuery;
import com.student.auth.util.PageList;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

//实现类
public interface PaperService {
    /**
     * 分页方法
     */
    PageList listpage(PaperQuery paperQuery);
    /**
     * 查询所有的paper
     */
    List<Paper> findAll();

    void savePaper(Paper paper);

    void editSavePaper(Paper paper);

    void deletePaper(Long id);

    /**
     * 试题组卷：根据试卷id查询对应的问题记录
     * @param paperId
     * @return
     */
    List<PaperQuestion> queryQuestionByPaperId(Long paperId);

    /**
     * 手动组卷
     * @param paperQuestion
     */
    void diyPaperQuestion(PaperQuestion paperQuestion);

    /**
     * 预览试卷方法
     * @param paperId
     * @return
     */
    PaperGengerateVO previewPaper(Long paperId);

    /**5.1.3
     * 查询题型的总数  group by根据 q_typeid来查询totalNum总数量  如选择题一共5条
     * @return
     */
    @Select("select q_typeid,count(*) totalNum\n" +
            "from exam_questionbank\n" +
            "group by q_typeid")
    List<TypeTotalVO> queryTypeTotal();


    /**
     * 随机组卷
     * @param mp
     */
    void randomPaperQuestion(Map mp);

}

