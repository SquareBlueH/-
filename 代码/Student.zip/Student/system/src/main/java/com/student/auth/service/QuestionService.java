package com.student.auth.service;

import com.student.auth.entity.Question;
import com.student.auth.query.QuestionQuery;
import com.student.auth.util.PageList;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;

/**
* @description: QuestionService
*/
public interface QuestionService {
    /**
     * 分页查询数据
     *
     * @param questionQuery
     * @return
     */
    PageList listPage(QuestionQuery questionQuery);


    /**
     * 保存问题方法
     * @param question
     */
    void addQuestion(Question question);


    Question queryQuestionByQid(Long qid);

    /**
     * 根据问题id修改问题
     * @param question
     */
    void editQuestion(Question question);

    /**
     * 根据问题id删除问题
     * @param id
     */
    void deleteQuestion(Long id);

    @Transactional
    void randomPaperQuestion(Map mp);
}
