package com.student.auth.service;

import com.student.auth.entity.ScoreDetail;
import com.student.auth.entity.StuScoreVO;
import com.student.auth.query.ScoreDetailQuery;
import com.student.auth.util.PageList;

import java.util.List;

/**
 * @description: ScoreDetailService 考试记录
 */
public interface ScoreDetailService {
    /**
     * 保存考试记录
     * @param scoreDetailList
     */
    void savePaperTestRecord(List<ScoreDetail> scoreDetailList);

    /**
     * 查询学生成绩
     * @param stuScoreVO
     * @return
     */
    StuScoreVO queryFrontStuScore(StuScoreVO stuScoreVO);

//    1.7、查询全部成绩
    List<StuScoreVO> queryFrontAllStuScore( Long stuId);

    /**七、老师功能完善
     1.1、老师阅卷功能列表
     * 老师阅卷：分页查询考试记录数据
     */
    PageList listPage(ScoreDetailQuery scoreDetailQuery);

}
