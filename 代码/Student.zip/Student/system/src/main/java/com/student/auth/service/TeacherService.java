package com.student.auth.service;

import com.student.auth.entity.ScoreDetail;
import com.student.auth.entity.User;
import com.student.auth.query.UserQuery;
import com.student.auth.util.PageList;

public interface TeacherService {
    public Long addTeacher(User user);

    /**
     * 分页查询数据
     * @param userQuery
     * @return
     */
    PageList listPage(UserQuery userQuery);

    /**1.2、实现老师阅卷功能
     * 老师阅卷操作
     * @param scoreDetail
     */
    void updateJdtScore(ScoreDetail scoreDetail);

}
