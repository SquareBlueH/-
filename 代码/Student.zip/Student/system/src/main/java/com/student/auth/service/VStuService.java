package com.student.auth.service;

import com.student.auth.query.VStuQuery;
import com.student.auth.util.PageList;

public interface VStuService {

    /**1.3、成绩管理
     * 分页查询数据
     * @param vStuQuery
     * @return
     */
    PageList listPage(VStuQuery vStuQuery);
}
