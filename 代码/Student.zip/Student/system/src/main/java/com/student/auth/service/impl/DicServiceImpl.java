package com.student.auth.service.impl;

import com.student.auth.entity.DicTypeData;
import com.student.auth.mapper.DicMapper;
import com.student.auth.service.DicService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DicServiceImpl implements DicService {
@Autowired
private DicMapper dicMapper;
/**
* 查询试卷等级
* @return
*/
@Override
public List<DicTypeData> findLevels() {
return dicMapper.findLevels();
}
}