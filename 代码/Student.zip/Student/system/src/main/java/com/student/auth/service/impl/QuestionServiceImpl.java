package com.student.auth.service.impl;

import com.student.auth.entity.Question;
import com.student.auth.entity.QuestionXztOptions;
import com.student.auth.mapper.QuestionMapper;
import com.student.auth.query.QuestionQuery;
import com.student.auth.service.QuestionService;
import com.student.auth.util.CommonUtils;
import com.student.auth.util.PageList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;
import java.util.Map;


//编写业务方法
@Service
public class QuestionServiceImpl implements QuestionService {
    @Autowired
    private QuestionMapper questionMapper;

    /**
    * 分页查询数据
    * @param questionQuery
    * @return
    */
    @Override
    public PageList listPage(QuestionQuery questionQuery) {
        PageList pageList = new PageList();
        //查询总的条数
        Long total = questionMapper.queryTotal(questionQuery);
        pageList.setTotal(total);
        //查询每页的数据
        List<Question> questions = questionMapper.queryData(questionQuery);
        pageList.setRows(questions);
        return pageList;
    }

    /**
     * 保存问题方法
     *
     * @param question
     */
    @Override
    @Transactional //涉及两张表，添加事务
    public void addQuestion(Question question) {
        //第一张表 exam_questionbank
        //（1）把题目 保存在 题库表 exam_questionbank
        question.setStatus(0L);
        question.setCreateTime(new Date());
        //返回主键 id，用亍把 选项 ABCD 保存迚 表 exam_xzt_options
        //CommonUtils.getLoginUser().getId() 获取用户名id
        question.setCreatorId(CommonUtils.getLoginUser().getId());
        //此时 question 对象丌仅有前台传来的参数，还有设置的字段 Status 状态CreateTime 创建时间 CreatorId 创建者
        questionMapper.addQuestion(question);
        //第二张表 exam_xzt_options 选择题选项表 abcd
        //如果是选择题 则把选择题的选项保存进选项表
        if (question.getQ_typeid() == 1L) {//（1.题型 选择题）如果是选择题
            QuestionXztOptions questionXztOptions = question.getQuestionXztOptions();//question.getQuestionXztOptions()（2.选项ABCD）
            questionXztOptions.setQuestionId(question.getId()); //即 questionId=id 把两张表联系起来
        //此时的 questionXztOptions 包括了 questionId
            questionMapper.addXztOptions(questionXztOptions);
        }
    }

    /**
     * 根据问题id查询问题   返回值类型为Question实体表
     *
     * @param qid
     * @return
     */
    @Override
    public Question queryQuestionByQid(Long qid) {
        return questionMapper.queryQuestionByQid(qid);
    }

    /**
     * 根据id修改问题方法
     不管什么题型 都去删除一下 选择题选项数据  如果传过来的是选择题，再去插入  先删除再插入
     *
     * @param question
     */
    @Override
    @Transactional
    public void editQuestion(Question question) {
        question.setCreatorId(CommonUtils.getLoginUser().getId());//重新获取登录用户的id(即题目创建者)，防止其他人登录把题目改了，所以重新获取
        //修改问题
        questionMapper.updateQuestion(question);
        //如果是选择题
        questionMapper.deleteXztOptions(question.getId());
        if(question.getQ_typeid()==1L){
            QuestionXztOptions questionXztOptions = question.getQuestionXztOptions();
            questionXztOptions.setQuestionId(question.getId());
            questionMapper.addXztOptions(questionXztOptions);
        }
    }

    /**
     * 根据问题id删除问题
     * @param id
     *  id = 177   -->第一种方法： 根据id查询的问题  根据typeid 决定删不删除选项表数据   在删除问题表
     *  id = 177   --》第二种： 不管37 21  先删除选项表（没有则说明选中的题目不是选择题，那这步代码就无效，不管） 再删除问题表（问题类型）  （方法简单）
     */
    @Override
    @Transactional
    public void deleteQuestion(Long id) {
        //先删除选择题的选项表（没有则不用管，执行下一步删除问题表，先执行这步是为了先过滤掉选择题题型）
        questionMapper.deleteXztOptions(id);
        //在删除问题表
        questionMapper.deleteQuestion(id);
    }

    @Override
    public void randomPaperQuestion(Map mp) {

    }


}