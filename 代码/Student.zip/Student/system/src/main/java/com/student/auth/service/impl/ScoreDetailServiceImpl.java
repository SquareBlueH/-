package com.student.auth.service.impl;

import com.student.auth.entity.ScoreDetail;
import com.student.auth.entity.StuScoreVO;
import com.student.auth.mapper.ScoreDetailMapper;
import com.student.auth.query.ScoreDetailQuery;
import com.student.auth.service.ScoreDetailService;
import com.student.auth.util.PageList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @description:
 */
@Service
public class ScoreDetailServiceImpl implements ScoreDetailService {

    @Autowired
    private ScoreDetailMapper scoreDetailMapper;

    /**
     * 保存考试记录
     * @param scoreDetailList
     */
    @Override
    public void savePaperTestRecord(List<ScoreDetail> scoreDetailList) {
        scoreDetailMapper.savePaperTestRecord(scoreDetailList);//调用
    }

    /**1.5、学生查看分数
     * 查询学生的成绩
     * @param stuScoreVO
     * @return
     */
    @Override
    public StuScoreVO queryFrontStuScore(StuScoreVO stuScoreVO) {
        return scoreDetailMapper.queryFrontStuScore(stuScoreVO);
    }

//    1.7、查询全部成绩
    @Override
    public List<StuScoreVO> queryFrontAllStuScore(Long stuId) {
        return scoreDetailMapper.queryFrontAllStuScore(stuId);
    }



    /**
     * 七、老师功能完善
     * 1.1、老师阅卷功能列表
     * 老师阅卷：分页查询考试记录数据
     *
     * @param scoreDetailQuery
     */
    /**
     * 老师阅卷：分页查询考试记录
     * @param scoreDetailQuery
     * @return
     */
    @Override
    public PageList listPage(ScoreDetailQuery scoreDetailQuery) {
        PageList pageList = new PageList();
        //查询总的条数
        Long total = scoreDetailMapper.queryTotal(scoreDetailQuery);
        pageList.setTotal(total);
        //查询每页的数据
        List<ScoreDetail> scoreDetails =  scoreDetailMapper.queryData(scoreDetailQuery);
        pageList.setRows(scoreDetails);
        return pageList;
    }


}
