package com.student.auth.service.impl;

import com.student.auth.entity.ScoreDetail;
import com.student.auth.entity.StuPaperQuestion;
import com.student.auth.mapper.StuQuestionRecordsMapper;
import com.student.auth.service.StuQuestionRecordsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/*
1.6、学生回顾试卷
 */
@Service
public class StuQuestionRecordsServiceimpl implements StuQuestionRecordsService {

    @Autowired
    private StuQuestionRecordsMapper stuQuestionRecordsMapper;
    /**
     * 查询学生考卷的每个问题的细节
     *
     * @param scoreDetail
     * @return
     */
    @Override
    public StuPaperQuestion queryPaperDetail(ScoreDetail scoreDetail) {
        return stuQuestionRecordsMapper.queryPaperDetail(scoreDetail);
    }
}