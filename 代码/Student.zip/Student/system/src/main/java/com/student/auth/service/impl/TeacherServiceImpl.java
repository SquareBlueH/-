package com.student.auth.service.impl;

import com.student.auth.entity.ScoreDetail;
import com.student.auth.entity.User;
import com.student.auth.mapper.ScoreDetailMapper;
import com.student.auth.mapper.UserMapper;
import com.student.auth.query.UserQuery;
import com.student.auth.service.TeacherService;
import com.student.auth.util.PageList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class TeacherServiceImpl implements TeacherService{

    @Autowired
    private UserMapper userMapper;

    @Override
    public Long addTeacher(User user){
        //设置注册时间
        user.setCreateTime(new Date());

        //设置角色2代表老师，角色1代表管理员
        user.setType(2);

        //密码加密
        user.setPassword(new BCryptPasswordEncoder().encode(user.getPassword()));

        //添加数据
        userMapper.addUser(user);

        //返回id

        return user.getId();



    }

    /**
     * 分页查询数据
     *
     * @param userQuery
     * @return
     */
    @Override
    public PageList listPage(UserQuery userQuery) {
        PageList pageList = new PageList();

        //查询t_user 表数据库
        Long along = userMapper.queryTotal(userQuery);

        //查询分页数据
        List<User> users = userMapper.queryData(userQuery);

        //封装
        pageList.setTotal(along);
        pageList.setRows(users);
        return pageList;
    }

    /**
     * 1.2、实现老师阅卷功能
     * 老师阅卷操作
     *
     * @param scoreDetail
     */
    @Autowired
    private ScoreDetailMapper scoreDetailMapper;
    @Override
    public void updateJdtScore(ScoreDetail scoreDetail) {
        scoreDetailMapper.updateJdtScore(scoreDetail);
    }
}
