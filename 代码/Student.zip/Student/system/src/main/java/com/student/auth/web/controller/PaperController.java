package com.student.auth.web.controller;

import com.student.auth.entity.*;
import com.student.auth.query.PaperQuery;
import com.student.auth.service.DicService;
import com.student.auth.service.PaperService;
import com.student.auth.util.MzResult;
import com.student.auth.util.PageList;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
//项目是控制器


@Controller
@Api(tags = "在线考试系统-试卷管理接口")
public class PaperController {

    //容器托管
    @Autowired
    private PaperService paperService;

    @Autowired
    private DicService dicService;


    @RequestMapping("/paper/queryPaper")
    @ResponseBody
    public List findAll(){
        List<Paper> papers = paperService.findAll();
        return papers;
    }

    @RequestMapping("/paper/index")
    public String index(Model model){
        //获取试卷等级数据
        List<DicTypeData> levels = dicService.findLevels();
        //将数据保存在model 域数据中， k,v
        model.addAttribute("levels",levels);
        //试题首页
        return "views/paper/paper_list";
    }


    @RequestMapping("/paper/listpage")
    @ResponseBody
     public PageList listpage(PaperQuery paperQuery){
        return paperService.listpage(paperQuery);
    }

    //添加内容
    @PostMapping("/paper/savePaper")
    @ResponseBody
    public MzResult savePaper(Paper paper){
        try
        {
            paperService.savePaper(paper);
            //表示操作成功信息放回前台
            return MzResult.ok();
        }catch (Exception e){
            //表示操作失败信息放回前台
            return MzResult.error(e.getMessage());
        }
    }

    //修改内容
    @PostMapping("/paper/editSavePaper")
    @ResponseBody
    public MzResult editSavePaper(Paper paper){
        try
        {
            paperService.editSavePaper(paper);
            //表示操作成功信息放回前台
            return MzResult.ok();
        }catch (Exception e){
            //表示操作失败信息放回前台
            return MzResult.error(e.getMessage());
        }
    }

    //删除内容
    @PostMapping("/paper/deletePaper")
    @ResponseBody
    public MzResult deletePaper(Long id){
        try
        {
            paperService.deletePaper(id);
            //表示操作成功信息放回前台
            return MzResult.ok();
        }catch (Exception e){
            //表示操作失败信息放回前台
            return MzResult.error(e.getMessage());
        }
    }

    /**
     * 跳转 试卷组题页面
     * @return
     */
    @GetMapping("/paper/appendQuestion")
    public String appendQuestion(){
        return "views/paper/paper_question";
    }

    /**
     * 根据试卷id查询所有的问题
     * @return   List<PaperQuestion>
     */
    @PostMapping("/paper/queryQuestionByPaperId")
    @ResponseBody
    public List<PaperQuestion> queryQuestionByPaperId(@RequestBody PaperQuestion paperQuestion) {
        return paperService.queryQuestionByPaperId(paperQuestion.getPaperId());
    }


    /**
     * 手动组卷
     * @param paperQuestion
     * @return
     */
    @PostMapping("/paper/diyPaperQuestion")
    @ResponseBody
//实体表 的paperQuestion对象
    public MzResult diyPaperQuestion(@RequestBody PaperQuestion paperQuestion) {
        try {
            paperService.diyPaperQuestion(paperQuestion);
            return MzResult.ok();
        } catch (Exception e) {
            e.printStackTrace();
            return MzResult.error(e.getMessage());
        }
    }


    /**
     * 根据id查询预览试卷信息 跳转页面进行预览试卷
     * @param paperId
     * @return
     */
    @RequestMapping("/paper/previewPaper/{paperId}")
    public String previewPaper(@PathVariable("paperId") Long paperId, Model model){
        //根据试卷id 查询出试卷的信息
        PaperGengerateVO paperGengerateVO= paperService.previewPaper(paperId);
        //model来存储查询到的信息，paperGengerateVO对象，然后前台再把信息取出来
        model.addAttribute("paperGengerateVO",paperGengerateVO);
        //跳转到预览页面
        return "views/paper/paper_preview";
    }


    /**
     * 查询题型的总数  List<TypeTotalVO>
     * queryTypeTotal
     */
    //对应的控制器业务接口
    @PostMapping("/paper/queryTypeTotal")
    @ResponseBody  //返回的json格式的数据
    public List<TypeTotalVO> queryTypeTotal(){
        return paperService.queryTypeTotal();
    }


    /**1.5、 随机组卷操作
     * 随机组卷的方法
     */
    @PostMapping("/paper/randomPaperQuestion")
    @ResponseBody
    public MzResult randomPaperQuestion(@RequestBody Map mp){
        try {
            paperService.randomPaperQuestion(mp);
            return MzResult.ok();//返回成功
        } catch (Exception e) {
            e.printStackTrace();
            return MzResult.error(e.getMessage());//返回失败，打印出失败消息
        }
    }





}
