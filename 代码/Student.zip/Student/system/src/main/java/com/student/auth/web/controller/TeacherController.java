package com.student.auth.web.controller;

import com.student.auth.entity.ScoreDetail;
import com.student.auth.entity.User;
import com.student.auth.query.ScoreDetailQuery;
import com.student.auth.query.UserQuery;
import com.student.auth.service.ScoreDetailService;
import com.student.auth.service.TeacherService;
import com.student.auth.util.MzResult;
import com.student.auth.util.PageList;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@Api(tags = "在线考试系统-教师管理接口")
public class TeacherController {

    //教师注册功能
    /*
    @param user 将注册的数据封装到User
    @return
     */
    @Autowired
    private TeacherService teacherService;
    //添加用户
    @RequestMapping("/teacher/addTeacher")
    @ResponseBody//将数据以json 发送给前台
    public Long addTeacher(User user) {
        //实现注册功能
        System.out.println("保存老师用户...." + user);
        user.setType(2);//type=2是老师
//        teacherService.addTeacher(user);
        Long userId =teacherService.addTeacher(user);
//        Long userId = user.getId();
        return userId;
    }
    @GetMapping("/teacher/index")
    public String index(){
        //请求跳转老师页面表的数据
        return "views/teacher/teacher_list";
    }
    @GetMapping("/teacher/listpage")
    @ResponseBody//将查询数据放回json格式
    public PageList getList(UserQuery userQuery){
        // 将查询数据放回给前台
        return teacherService.listPage(userQuery);
    }


    @Autowired
    private ScoreDetailService scoreDetailService;
    /**
     * 七、老师功能完善
     * 1.1、老师阅卷功能列表
     * 跳转老师阅卷页面
     * @return
     */
    @GetMapping("/teacher/paperExamRecord")
    public String paperExamRecord(){
        return "views/teacher/paper_check";
    }
    /**
     * 老师阅卷
     * /teacher/paperExamlistpage
     * @param scoreDetailQuery
     * @return
     */
    @GetMapping("/teacher/paperExamlistpage")
    @ResponseBody
    public PageList listPaperExamPage(ScoreDetailQuery scoreDetailQuery){
        return scoreDetailService.listPage(scoreDetailQuery);
    }


    /**1.2、实现老师阅卷功能
     * 老师阅卷操作
     * @param scoreDetail
     * @return
     */
    @PostMapping("/teacher/updateJdtScore")
    @ResponseBody
    public MzResult updateJdtScore(ScoreDetail scoreDetail){
        try {
            teacherService.updateJdtScore(scoreDetail);
            return MzResult.ok();
        } catch (Exception e) {
            e.printStackTrace();
            return MzResult.error(e.getMessage());
        }
    }



}