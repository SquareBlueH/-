package com.student.auth.web.controller;

import com.student.auth.query.VStuQuery;
import com.student.auth.service.VStuService;
import com.student.auth.util.PageList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**1.3、成绩管理
 * @description: VStuController
 */
@Controller
public class VStuController {

    @Autowired
    private VStuService vStuService;
    /**
     * 跳转学生的列表页
     * @return
     */
    @GetMapping("/score/index")
    public String index(){
        return "views/score/score_list";
    }

    /**
     * 成绩查询 分页
     * @return
     */
    @GetMapping("/score/listpage")
    @ResponseBody
    public PageList listPage(VStuQuery vStuQuery){
        return vStuService.listPage(vStuQuery);
    }


}
