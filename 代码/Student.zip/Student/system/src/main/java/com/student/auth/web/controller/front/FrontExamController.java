package com.student.auth.web.controller.front;

import com.student.auth.entity.PaperGengerateVO;
import com.student.auth.entity.ScoreDetail;
import com.student.auth.service.PaperService;
import com.student.auth.service.ScoreDetailService;
import com.student.auth.util.MzResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

/**
 * @description: FrontExamController 前台考试记录的controller
 */
@Controller
//处理考试相关的业务
public class FrontExamController {

    @Autowired
    private PaperService paperService;
    

    /**
     * 前台弹出测试（考试）页面
     * @param model
     * @param paperId
     * @return
     */
    @RequestMapping("/exam/popPaper/{paperId}")
    public String popPaper(Model model , @PathVariable("paperId") Long paperId){

        PaperGengerateVO paperGengerateVO = paperService.previewPaper(paperId);

        model.addAttribute("examPapersVO",paperGengerateVO);

        return "front/examPaper";
    }


    //1.4、完成学生开始考试功能
    @Autowired
    private ScoreDetailService scoreDetailService;
    /**
     * 保存学生考试记录
     * examPaper
     */
    @RequestMapping("/stu/examPaper")
    @ResponseBody
    public MzResult examPaper(@RequestBody List<ScoreDetail> scoreDetails){//@RequestBody前台是json形式的数据 到后台
        try {
            scoreDetailService.savePaperTestRecord(scoreDetails);
            return MzResult.ok();
        } catch (Exception e) {
            e.printStackTrace();
            return MzResult.error(e.getMessage());
        }
    }

}
